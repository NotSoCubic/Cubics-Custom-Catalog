Rush Out
by WEG Fan (recreated by ~cloud~)


Put this strings of text underneath <standard> <extended> or <bonus> in mapping.xml.

<level filename="rush_out" />


Put the BIN file in the "levels" folder and the ESO file in the "models" folder.

Then, launch the game and play this level!