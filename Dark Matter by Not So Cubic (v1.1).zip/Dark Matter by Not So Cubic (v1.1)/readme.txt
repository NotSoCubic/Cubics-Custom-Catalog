Dark Matter
Not So Cubic

Put this string of text underneath <standard> <extended> or <bonus> in mapping.xml.

<level filename="dark matter" />

Put the BIN file in the "levels" folder and the ESO file in the "models" folder.

Then, launch the game!

Thanks to Cubing Machine for helping me with Darkcube movements.
Thanks to CatLooks for helping with small stuff.

Update Log:

v1.0: Official Relase
v1.1: Made middle ending easier and second last Darkcube part harder. Fixed a moving platform that was kind of hard to use.