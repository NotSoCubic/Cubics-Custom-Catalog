EDGE Old Levels
Metro (Mobile)
by Mobigame (recreated by Not So Cubic)


Put this string of text underneath <standard> <extended> or <bonus> in mapping.xml.

<level filename="level301_old" name_sfx="metro" />


Put the BIN file in the "levels" folder and the ESO file in the "models" folder.

Then, launch the game and play this level!